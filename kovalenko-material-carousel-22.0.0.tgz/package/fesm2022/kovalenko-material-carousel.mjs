import { ListKeyManager } from "@angular/cdk/a11y";
import { NgTemplateOutlet, isPlatformBrowser } from "@angular/common";
import * as i0 from "@angular/core";
import { Component, DestroyRef, HostListener, Injector, PLATFORM_ID, Renderer2, TemplateRef, computed, contentChildren, effect, inject, input, model, output, signal, viewChild } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { MatIconButton, MatMiniFabButton } from "@angular/material/button";
import { MatIcon } from "@angular/material/icon";
import { Subject, interval } from "rxjs";
import { filter, takeUntil } from "rxjs/operators";
import { DomSanitizer } from "@angular/platform-browser";
var MatCarouselSlideComponent = class MatCarouselSlideComponent {
	image = input(...ngDevMode ? [void 0, { debugName: "image" }] : /* istanbul ignore next */ []);
	overlayColor = input("#00000040", ...ngDevMode ? [{ debugName: "overlayColor" }] : /* istanbul ignore next */ []);
	hideOverlay = input(false, ...ngDevMode ? [{ debugName: "hideOverlay" }] : /* istanbul ignore next */ []);
	disabledInput = model(false, {
		...ngDevMode ? { debugName: "disabledInput" } : /* istanbul ignore next */ {},
		alias: "disabled"
	});
	templateRef = viewChild.required(TemplateRef, ...ngDevMode ? [{ debugName: "templateRef" }] : /* istanbul ignore next */ []);
	sanitizer = inject(DomSanitizer);
	backgroundImage = computed(() => {
		const image = this.image();
		return image ? this.sanitizer.bypassSecurityTrustStyle(`url('${image}')`) : null;
	}, ...ngDevMode ? [{ debugName: "backgroundImage" }] : /* istanbul ignore next */ []);
	get disabled() {
		return this.disabledInput();
	}
	set disabled(value) {
		this.disabledInput.set(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: MatCarouselSlideComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.2",
		type: MatCarouselSlideComponent,
		isStandalone: true,
		selector: "mat-carousel-slide",
		inputs: {
			image: {
				classPropertyName: "image",
				publicName: "image",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			overlayColor: {
				classPropertyName: "overlayColor",
				publicName: "overlayColor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideOverlay: {
				classPropertyName: "hideOverlay",
				publicName: "hideOverlay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabledInput: {
				classPropertyName: "disabledInput",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { disabledInput: "disabledChange" },
		viewQueries: [{
			propertyName: "templateRef",
			first: true,
			predicate: TemplateRef,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-template>\n  <div class=\"carousel-slide\" [style.background-image]=\"backgroundImage()\">\n    <div class=\"carousel-slide-content\"><ng-content></ng-content></div>\n    @if (!hideOverlay()) {\n      <div\n        class=\"carousel-slide-overlay\"\n        [style.background-color]=\"overlayColor()\"\n      ></div>\n    }\n  </div>\n</ng-template>\n",
		styles: [".carousel-slide{width:100%;height:100%;position:absolute;z-index:auto;background-size:cover;background-repeat:no-repeat;background-position:center}.carousel-slide-overlay{width:100%;height:100%;position:absolute;z-index:auto}.carousel-slide-content{width:100%;height:100%;position:absolute;z-index:1}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: MatCarouselSlideComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mat-carousel-slide",
			standalone: true,
			template: "<ng-template>\n  <div class=\"carousel-slide\" [style.background-image]=\"backgroundImage()\">\n    <div class=\"carousel-slide-content\"><ng-content></ng-content></div>\n    @if (!hideOverlay()) {\n      <div\n        class=\"carousel-slide-overlay\"\n        [style.background-color]=\"overlayColor()\"\n      ></div>\n    }\n  </div>\n</ng-template>\n",
			styles: [".carousel-slide{width:100%;height:100%;position:absolute;z-index:auto;background-size:cover;background-repeat:no-repeat;background-position:center}.carousel-slide-overlay{width:100%;height:100%;position:absolute;z-index:auto}.carousel-slide-content{width:100%;height:100%;position:absolute;z-index:1}\n"]
		}]
	}],
	propDecorators: {
		image: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "image",
				required: false
			}]
		}],
		overlayColor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "overlayColor",
				required: false
			}]
		}],
		hideOverlay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideOverlay",
				required: false
			}]
		}],
		disabledInput: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["disabledChange"]
		}],
		templateRef: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => TemplateRef), { isSignal: true }]
		}]
	}
});
var Direction;
(function(Direction) {
	Direction[Direction["Left"] = 0] = "Left";
	Direction[Direction["Right"] = 1] = "Right";
	Direction[Direction["Index"] = 2] = "Index";
})(Direction || (Direction = {}));
var MatCarouselComponent = class MatCarouselComponent {
	timings = input("250ms ease-in", ...ngDevMode ? [{ debugName: "timings" }] : /* istanbul ignore next */ []);
	svgIconOverrides = input(...ngDevMode ? [void 0, { debugName: "svgIconOverrides" }] : /* istanbul ignore next */ []);
	autoplay = input(true, ...ngDevMode ? [{ debugName: "autoplay" }] : /* istanbul ignore next */ []);
	interval = input(5e3, ...ngDevMode ? [{ debugName: "interval" }] : /* istanbul ignore next */ []);
	loop = input(true, ...ngDevMode ? [{ debugName: "loop" }] : /* istanbul ignore next */ []);
	hideArrows = input(true, ...ngDevMode ? [{ debugName: "hideArrows" }] : /* istanbul ignore next */ []);
	hideIndicators = input(true, ...ngDevMode ? [{ debugName: "hideIndicators" }] : /* istanbul ignore next */ []);
	pauseOnHover = input(true, ...ngDevMode ? [{ debugName: "pauseOnHover" }] : /* istanbul ignore next */ []);
	color = input("accent", ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	maxWidth = input("auto", ...ngDevMode ? [{ debugName: "maxWidth" }] : /* istanbul ignore next */ []);
	maintainAspectRatio = input(true, ...ngDevMode ? [{ debugName: "maintainAspectRatio" }] : /* istanbul ignore next */ []);
	proportion = input(25, ...ngDevMode ? [{ debugName: "proportion" }] : /* istanbul ignore next */ []);
	slideHeight = input("100%", ...ngDevMode ? [{ debugName: "slideHeight" }] : /* istanbul ignore next */ []);
	slides = input(...ngDevMode ? [void 0, { debugName: "slides" }] : /* istanbul ignore next */ []);
	useKeyboard = input(false, ...ngDevMode ? [{ debugName: "useKeyboard" }] : /* istanbul ignore next */ []);
	useMouseWheel = input(false, ...ngDevMode ? [{ debugName: "useMouseWheel" }] : /* istanbul ignore next */ []);
	orientation = input("ltr", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	animationStart = output();
	change = output();
	currentIndex = signal(0, ...ngDevMode ? [{ debugName: "currentIndex" }] : /* istanbul ignore next */ []);
	slidesList = contentChildren(MatCarouselSlideComponent, ...ngDevMode ? [{ debugName: "slidesList" }] : /* istanbul ignore next */ []);
	visibleSlides = computed(() => {
		const slides = this.slides();
		const list = this.slidesList();
		return slides != null && slides < list.length ? list.slice(0, slides) : list;
	}, ...ngDevMode ? [{ debugName: "visibleSlides" }] : /* istanbul ignore next */ []);
	carouselContainerRef = viewChild.required("carouselContainer", ...ngDevMode ? [{ debugName: "carouselContainerRef" }] : /* istanbul ignore next */ []);
	carouselListRef = viewChild.required("carouselList", ...ngDevMode ? [{ debugName: "carouselListRef" }] : /* istanbul ignore next */ []);
	translation = signal("translateX(0px)", ...ngDevMode ? [{ debugName: "translation" }] : /* istanbul ignore next */ []);
	listKeyManager;
	timer$;
	timerStop$ = new Subject();
	animationPending = false;
	animationTimeout = null;
	pressed = false;
	dragging = false;
	dragStartX = 0;
	dragStartY = 0;
	dragThreshold = 12;
	renderer = inject(Renderer2);
	platformId = inject(PLATFORM_ID);
	destroyRef = inject(DestroyRef);
	injector = inject(Injector);
	get currentSlide() {
		return this.listKeyManager?.activeItem ?? null;
	}
	constructor() {
		effect(() => {
			const loop = this.loop();
			this.listKeyManager?.withWrap(loop);
		});
		effect(() => {
			const orientation = this.orientation();
			this.listKeyManager?.withHorizontalOrientation(orientation);
		});
		effect(() => {
			this.maxWidth();
			this.slideTo(0);
		});
		effect(() => {
			this.interval();
			this.autoplay();
			this.stopTimer();
			this.startTimer();
		});
		this.destroyRef.onDestroy(() => {
			this.clearAnimationTimeout();
			this.listKeyManager?.destroy();
		});
	}
	ngAfterContentInit() {
		this.listKeyManager = new ListKeyManager(this.visibleSlides, this.injector).withVerticalOrientation(false).withHorizontalOrientation(this.orientation()).withWrap(this.loop());
		this.listKeyManager.updateActiveItem(0);
		this.listKeyManager.change.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((index) => {
			this.currentIndex.set(index);
			this.playAnimation();
		});
	}
	next() {
		this.goto(Direction.Right);
	}
	previous() {
		this.goto(Direction.Left);
	}
	slideTo(index) {
		this.goto(Direction.Index, index);
	}
	onKeyUp(event) {
		if (this.useKeyboard()) this.listKeyManager?.onKeydown(event);
	}
	onMouseEnter() {
		if (this.pauseOnHover()) this.stopTimer();
	}
	onMouseLeave() {
		if (this.pauseOnHover()) this.startTimer();
	}
	onMouseWheel(event) {
		if (this.useMouseWheel()) {
			event.preventDefault();
			const delta = Math.sign(event.deltaY);
			if (delta > 0) this.next();
			else if (delta < 0) this.previous();
		}
	}
	onResize() {
		this.slideTo(0);
	}
	onTransitionEnd(event) {
		if (event.target === this.carouselListRef().nativeElement && event.propertyName === "transform") this.finishAnimation();
	}
	onDragStart(event) {
		if (event.pointerType === "mouse" && event.button !== 0) return;
		this.pressed = true;
		this.dragging = false;
		this.dragStartX = event.clientX;
		this.dragStartY = event.clientY;
	}
	onDrag(event, slideElem) {
		if (!this.pressed) return;
		const deltaX = event.clientX - this.dragStartX;
		const deltaY = event.clientY - this.dragStartY;
		if (!this.dragging) {
			if (!(Math.abs(deltaX) > this.dragThreshold && Math.abs(deltaX) > Math.abs(deltaY))) return;
			this.dragging = true;
			event.currentTarget.setPointerCapture(event.pointerId);
		}
		if (Math.abs(deltaY) > Math.abs(deltaX)) return;
		let adjustedDelta = deltaX;
		if (this.isOutOfBounds()) adjustedDelta *= .2;
		this.renderer.setStyle(slideElem, "cursor", "grabbing");
		this.translation.set(this.getTranslation(this.getOffset() + adjustedDelta));
	}
	onDragEnd(event, slideElem) {
		this.pressed = false;
		if (!this.dragging) return;
		this.dragging = false;
		this.renderer.removeStyle(slideElem, "cursor");
		const deltaX = event.clientX - this.dragStartX;
		if (!this.isOutOfBounds() && Math.abs(deltaX) > this.getWidth() * .25) {
			if (deltaX <= 0) {
				this.next();
				return;
			}
			this.previous();
			return;
		}
		this.playAnimation();
	}
	isOutOfBounds() {
		const sign = this.orientation() === "rtl" ? -1 : 1;
		const listEl = this.carouselListRef().nativeElement;
		const offsetParent = listEl.offsetParent;
		const parentLeft = offsetParent ? offsetParent.getBoundingClientRect().left : 0;
		const left = sign * (listEl.getBoundingClientRect().left - parentLeft);
		const lastIndex = this.visibleSlides().length - 1;
		const width = -this.getWidth() * lastIndex;
		return this.listKeyManager.activeItemIndex === 0 && left >= 0 || this.listKeyManager.activeItemIndex === lastIndex && left <= width;
	}
	isVisible() {
		if (!isPlatformBrowser(this.platformId)) return false;
		const container = this.carouselContainerRef();
		if (!container) return false;
		const elem = container.nativeElement;
		const docViewTop = window.pageYOffset;
		const docViewBottom = docViewTop + window.innerHeight;
		const elemOffset = elem.getBoundingClientRect();
		const elemTop = docViewTop + elemOffset.top;
		return elemTop + elemOffset.height <= docViewBottom || elemTop >= docViewTop;
	}
	getOffset() {
		const offset = this.currentIndex() * this.getWidth();
		return (this.orientation() === "rtl" ? 1 : -1) * offset;
	}
	getTranslation(offset) {
		return `translateX(${offset}px)`;
	}
	getWidth() {
		return this.carouselContainerRef().nativeElement.clientWidth;
	}
	goto(direction, index) {
		if (!this.listKeyManager) return;
		const rtl = this.orientation() === "rtl";
		switch (direction) {
			case Direction.Left: return rtl ? this.listKeyManager.setNextItemActive() : this.listKeyManager.setPreviousItemActive();
			case Direction.Right: return rtl ? this.listKeyManager.setPreviousItemActive() : this.listKeyManager.setNextItemActive();
			case Direction.Index: return this.listKeyManager.setActiveItem(index);
		}
	}
	playAnimation() {
		this.translation.set(this.getTranslation(this.getOffset()));
		this.animationStart.emit(this.currentIndex());
		this.scheduleAnimationEnd();
	}
	scheduleAnimationEnd() {
		this.clearAnimationTimeout();
		this.animationPending = true;
		const duration = this.getTransitionDuration(this.timings());
		this.animationTimeout = setTimeout(() => this.finishAnimation(), duration + 16);
	}
	finishAnimation() {
		if (!this.animationPending) return;
		this.animationPending = false;
		this.clearAnimationTimeout();
		this.change.emit(this.currentIndex());
	}
	getTransitionDuration(timings) {
		const match = timings.match(/(\d+(?:\.\d+)?)(ms|s)/);
		if (!match) return 250;
		const value = parseFloat(match[1]);
		return match[2] === "s" ? value * 1e3 : value;
	}
	clearAnimationTimeout() {
		if (this.animationTimeout != null) {
			clearTimeout(this.animationTimeout);
			this.animationTimeout = null;
		}
	}
	resetTimer() {
		this.timer$ = interval(this.interval());
	}
	startTimer() {
		if (!this.autoplay()) return;
		this.resetTimer();
		this.timer$.pipe(takeUntil(this.timerStop$), takeUntilDestroyed(this.destroyRef), filter(() => this.isVisible())).subscribe(() => {
			this.listKeyManager?.withWrap(true).setNextItemActive();
			this.listKeyManager?.withWrap(this.loop());
		});
	}
	stopTimer() {
		this.timerStop$.next(void 0);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: MatCarouselComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.2",
		type: MatCarouselComponent,
		isStandalone: true,
		selector: "mat-carousel",
		inputs: {
			timings: {
				classPropertyName: "timings",
				publicName: "timings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			svgIconOverrides: {
				classPropertyName: "svgIconOverrides",
				publicName: "svgIconOverrides",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoplay: {
				classPropertyName: "autoplay",
				publicName: "autoplay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			interval: {
				classPropertyName: "interval",
				publicName: "interval",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loop: {
				classPropertyName: "loop",
				publicName: "loop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideArrows: {
				classPropertyName: "hideArrows",
				publicName: "hideArrows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideIndicators: {
				classPropertyName: "hideIndicators",
				publicName: "hideIndicators",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pauseOnHover: {
				classPropertyName: "pauseOnHover",
				publicName: "pauseOnHover",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxWidth: {
				classPropertyName: "maxWidth",
				publicName: "maxWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maintainAspectRatio: {
				classPropertyName: "maintainAspectRatio",
				publicName: "maintainAspectRatio",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			proportion: {
				classPropertyName: "proportion",
				publicName: "proportion",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			slideHeight: {
				classPropertyName: "slideHeight",
				publicName: "slideHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			slides: {
				classPropertyName: "slides",
				publicName: "slides",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			useKeyboard: {
				classPropertyName: "useKeyboard",
				publicName: "useKeyboard",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			useMouseWheel: {
				classPropertyName: "useMouseWheel",
				publicName: "useMouseWheel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			animationStart: "animationStart",
			change: "change"
		},
		host: { listeners: {
			"keyup": "onKeyUp($event)",
			"mouseenter": "onMouseEnter()",
			"mouseleave": "onMouseLeave()",
			"mousewheel": "onMouseWheel($event)",
			"window:resize": "onResize()",
			"transitionend": "onTransitionEnd($event)"
		} },
		queries: [{
			propertyName: "slidesList",
			predicate: MatCarouselSlideComponent,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "carouselContainerRef",
			first: true,
			predicate: ["carouselContainer"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "carouselListRef",
			first: true,
			predicate: ["carouselList"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div\n  #carouselContainer\n  class=\"carousel\"\n  tabindex=\"0\"\n  [style.max-width]=\"maxWidth()\"\n  [style.height]=\"!maintainAspectRatio() ? '100%' : 'auto'\"\n>\n  <ul\n    #carouselList\n    class=\"carousel-list\"\n    role=\"listbox\"\n    [style.transform]=\"translation()\"\n    [style.transition]=\"timings()\"\n    [style.flex-direction]=\"orientation() === 'rtl' ? 'row-reverse' : 'row'\"\n    [style.height]=\"!maintainAspectRatio() ? '100%' : 'auto'\"\n  >\n    @for (slide of visibleSlides(); track slide) {\n      <li\n        #carouselSlide\n        class=\"carousel-slide\"\n        role=\"option\"\n        [style.padding-bottom]=\"maintainAspectRatio() && proportion() ? proportion() + '%' : '0px'\"\n        [style.height]=\"!maintainAspectRatio() && slideHeight() ? slideHeight() : '0px'\"\n        (pointerdown)=\"onDragStart($event)\"\n        (pointermove)=\"onDrag($event, carouselSlide)\"\n        (pointerup)=\"onDragEnd($event, carouselSlide)\"\n        (pointercancel)=\"onDragEnd($event, carouselSlide)\"\n      >\n        <ng-container [ngTemplateOutlet]=\"slide.templateRef()\"></ng-container>\n      </li>\n    }\n  </ul>\n\n  @if (!hideArrows()) {\n    <button\n      mat-icon-button\n      type=\"button\"\n      tabindex=\"-1\"\n      [color]=\"color()\"\n      [disabled]=\"!loop() && currentIndex() === 0\"\n      (click)=\"previous()\"\n    >\n      @if (svgIconOverrides()?.arrowBack; as arrowBack) {\n        <mat-icon [svgIcon]=\"arrowBack\"></mat-icon>\n      } @else {\n        <mat-icon>arrow_back</mat-icon>\n      }\n    </button>\n    <button\n      mat-icon-button\n      type=\"button\"\n      tabindex=\"-1\"\n      [color]=\"color()\"\n      [disabled]=\"!loop() && currentIndex() === visibleSlides().length - 1\"\n      (click)=\"next()\"\n    >\n      @if (svgIconOverrides()?.arrowForward; as arrowForward) {\n        <mat-icon [svgIcon]=\"arrowForward\"></mat-icon>\n      } @else {\n        <mat-icon>arrow_forward</mat-icon>\n      }\n    </button>\n  }\n\n  @if (!hideIndicators()) {\n    <div\n      class=\"carousel-indicators\"\n      tabindex=\"-1\"\n      [style.flex-direction]=\"orientation() === 'rtl' ? 'row-reverse' : 'row'\"\n    >\n      @for (slide of visibleSlides(); track slide; let i = $index) {\n        <button\n          type=\"button\"\n          tabindex=\"-1\"\n          mat-mini-fab\n          [color]=\"color()\"\n          [disabled]=\"i === currentIndex()\"\n          (click)=\"slideTo(i)\"\n          (focus)=\"carouselContainer.focus()\"\n        ></button>\n      }\n    </div>\n  }\n</div>\n",
		styles: [".carousel{width:100%;position:relative;overflow:hidden;outline:none}.carousel>button{position:absolute;z-index:1;top:50%;transform:translateY(-50%)}.carousel>button:first-of-type{left:30px}.carousel>button:last-of-type{right:30px}.carousel-list{width:100%;margin:0;padding:0;list-style:none;display:flex;position:relative}.carousel-slide{width:100%;height:0;display:flex;flex-shrink:0;position:relative}.carousel-slide:hover{cursor:grab}.carousel-indicators{display:flex;position:absolute;bottom:15px;z-index:1;left:50%;transform:translate(-50%);outline:none}.carousel-indicators>button{width:10px;height:10px;margin:7.5px}\n"],
		dependencies: [
			{
				kind: "component",
				type: MatIconButton,
				selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]",
				exportAs: ["matButton", "matAnchor"]
			},
			{
				kind: "component",
				type: MatMiniFabButton,
				selector: "button[mat-mini-fab], a[mat-mini-fab], button[matMiniFab], a[matMiniFab]",
				exportAs: ["matButton", "matAnchor"]
			},
			{
				kind: "component",
				type: MatIcon,
				selector: "mat-icon",
				inputs: [
					"color",
					"inline",
					"svgIcon",
					"fontSet",
					"fontIcon"
				],
				exportAs: ["matIcon"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: MatCarouselComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "mat-carousel",
			standalone: true,
			imports: [
				MatIconButton,
				MatMiniFabButton,
				MatIcon,
				NgTemplateOutlet
			],
			template: "<div\n  #carouselContainer\n  class=\"carousel\"\n  tabindex=\"0\"\n  [style.max-width]=\"maxWidth()\"\n  [style.height]=\"!maintainAspectRatio() ? '100%' : 'auto'\"\n>\n  <ul\n    #carouselList\n    class=\"carousel-list\"\n    role=\"listbox\"\n    [style.transform]=\"translation()\"\n    [style.transition]=\"timings()\"\n    [style.flex-direction]=\"orientation() === 'rtl' ? 'row-reverse' : 'row'\"\n    [style.height]=\"!maintainAspectRatio() ? '100%' : 'auto'\"\n  >\n    @for (slide of visibleSlides(); track slide) {\n      <li\n        #carouselSlide\n        class=\"carousel-slide\"\n        role=\"option\"\n        [style.padding-bottom]=\"maintainAspectRatio() && proportion() ? proportion() + '%' : '0px'\"\n        [style.height]=\"!maintainAspectRatio() && slideHeight() ? slideHeight() : '0px'\"\n        (pointerdown)=\"onDragStart($event)\"\n        (pointermove)=\"onDrag($event, carouselSlide)\"\n        (pointerup)=\"onDragEnd($event, carouselSlide)\"\n        (pointercancel)=\"onDragEnd($event, carouselSlide)\"\n      >\n        <ng-container [ngTemplateOutlet]=\"slide.templateRef()\"></ng-container>\n      </li>\n    }\n  </ul>\n\n  @if (!hideArrows()) {\n    <button\n      mat-icon-button\n      type=\"button\"\n      tabindex=\"-1\"\n      [color]=\"color()\"\n      [disabled]=\"!loop() && currentIndex() === 0\"\n      (click)=\"previous()\"\n    >\n      @if (svgIconOverrides()?.arrowBack; as arrowBack) {\n        <mat-icon [svgIcon]=\"arrowBack\"></mat-icon>\n      } @else {\n        <mat-icon>arrow_back</mat-icon>\n      }\n    </button>\n    <button\n      mat-icon-button\n      type=\"button\"\n      tabindex=\"-1\"\n      [color]=\"color()\"\n      [disabled]=\"!loop() && currentIndex() === visibleSlides().length - 1\"\n      (click)=\"next()\"\n    >\n      @if (svgIconOverrides()?.arrowForward; as arrowForward) {\n        <mat-icon [svgIcon]=\"arrowForward\"></mat-icon>\n      } @else {\n        <mat-icon>arrow_forward</mat-icon>\n      }\n    </button>\n  }\n\n  @if (!hideIndicators()) {\n    <div\n      class=\"carousel-indicators\"\n      tabindex=\"-1\"\n      [style.flex-direction]=\"orientation() === 'rtl' ? 'row-reverse' : 'row'\"\n    >\n      @for (slide of visibleSlides(); track slide; let i = $index) {\n        <button\n          type=\"button\"\n          tabindex=\"-1\"\n          mat-mini-fab\n          [color]=\"color()\"\n          [disabled]=\"i === currentIndex()\"\n          (click)=\"slideTo(i)\"\n          (focus)=\"carouselContainer.focus()\"\n        ></button>\n      }\n    </div>\n  }\n</div>\n",
			styles: [".carousel{width:100%;position:relative;overflow:hidden;outline:none}.carousel>button{position:absolute;z-index:1;top:50%;transform:translateY(-50%)}.carousel>button:first-of-type{left:30px}.carousel>button:last-of-type{right:30px}.carousel-list{width:100%;margin:0;padding:0;list-style:none;display:flex;position:relative}.carousel-slide{width:100%;height:0;display:flex;flex-shrink:0;position:relative}.carousel-slide:hover{cursor:grab}.carousel-indicators{display:flex;position:absolute;bottom:15px;z-index:1;left:50%;transform:translate(-50%);outline:none}.carousel-indicators>button{width:10px;height:10px;margin:7.5px}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		timings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "timings",
				required: false
			}]
		}],
		svgIconOverrides: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "svgIconOverrides",
				required: false
			}]
		}],
		autoplay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoplay",
				required: false
			}]
		}],
		interval: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "interval",
				required: false
			}]
		}],
		loop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loop",
				required: false
			}]
		}],
		hideArrows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideArrows",
				required: false
			}]
		}],
		hideIndicators: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideIndicators",
				required: false
			}]
		}],
		pauseOnHover: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pauseOnHover",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		maxWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxWidth",
				required: false
			}]
		}],
		maintainAspectRatio: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maintainAspectRatio",
				required: false
			}]
		}],
		proportion: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "proportion",
				required: false
			}]
		}],
		slideHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "slideHeight",
				required: false
			}]
		}],
		slides: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "slides",
				required: false
			}]
		}],
		useKeyboard: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "useKeyboard",
				required: false
			}]
		}],
		useMouseWheel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "useMouseWheel",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		animationStart: [{
			type: i0.Output,
			args: ["animationStart"]
		}],
		change: [{
			type: i0.Output,
			args: ["change"]
		}],
		slidesList: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => MatCarouselSlideComponent), { isSignal: true }]
		}],
		carouselContainerRef: [{
			type: i0.ViewChild,
			args: ["carouselContainer", { isSignal: true }]
		}],
		carouselListRef: [{
			type: i0.ViewChild,
			args: ["carouselList", { isSignal: true }]
		}],
		onKeyUp: [{
			type: HostListener,
			args: ["keyup", ["$event"]]
		}],
		onMouseEnter: [{
			type: HostListener,
			args: ["mouseenter"]
		}],
		onMouseLeave: [{
			type: HostListener,
			args: ["mouseleave"]
		}],
		onMouseWheel: [{
			type: HostListener,
			args: ["mousewheel", ["$event"]]
		}],
		onResize: [{
			type: HostListener,
			args: ["window:resize"]
		}],
		onTransitionEnd: [{
			type: HostListener,
			args: ["transitionend", ["$event"]]
		}]
	}
});
export { MatCarouselComponent, MatCarouselSlideComponent };

//# sourceMappingURL=kovalenko-material-carousel.mjs.map