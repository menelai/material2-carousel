import * as i0 from "@angular/core";
import { AfterContentInit, ElementRef, TemplateRef } from "@angular/core";
import { ThemePalette } from "@angular/material/core";
import { ListKeyManagerOption } from "@angular/cdk/a11y";
import { SafeStyle } from "@angular/platform-browser";
export type Orientation = 'ltr' | 'rtl';
export interface SvgIconOverrides {
  arrowBack: string;
  arrowForward: string;
}
export declare class MatCarouselSlideComponent implements ListKeyManagerOption {
  readonly image: import("@angular/core").InputSignal<string | undefined>;
  readonly overlayColor: import("@angular/core").InputSignal<string>;
  readonly hideOverlay: import("@angular/core").InputSignal<boolean>;
  readonly disabledInput: import("@angular/core").ModelSignal<boolean>;
  readonly templateRef: import("@angular/core").Signal<TemplateRef<any>>;
  private readonly sanitizer;
  readonly backgroundImage: import("@angular/core").Signal<SafeStyle | null>;
  get disabled(): boolean;
  set disabled(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<MatCarouselSlideComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MatCarouselSlideComponent, "mat-carousel-slide", never, {
    "image": {
      "alias": "image";
      "required": false;
      "isSignal": true;
    };
    "overlayColor": {
      "alias": "overlayColor";
      "required": false;
      "isSignal": true;
    };
    "hideOverlay": {
      "alias": "hideOverlay";
      "required": false;
      "isSignal": true;
    };
    "disabledInput": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "disabledInput": "disabledChange";
  }, never, ["*"], true, never>;
}
export declare class MatCarouselComponent implements AfterContentInit {
  readonly timings: import("@angular/core").InputSignal<string>;
  readonly svgIconOverrides: import("@angular/core").InputSignal<SvgIconOverrides | undefined>;
  readonly autoplay: import("@angular/core").InputSignal<boolean>;
  readonly interval: import("@angular/core").InputSignal<number>;
  readonly loop: import("@angular/core").InputSignal<boolean>;
  readonly hideArrows: import("@angular/core").InputSignal<boolean>;
  readonly hideIndicators: import("@angular/core").InputSignal<boolean>;
  readonly pauseOnHover: import("@angular/core").InputSignal<boolean>;
  readonly color: import("@angular/core").InputSignal<ThemePalette>;
  readonly maxWidth: import("@angular/core").InputSignal<string>;
  readonly maintainAspectRatio: import("@angular/core").InputSignal<boolean>;
  readonly proportion: import("@angular/core").InputSignal<number>;
  readonly slideHeight: import("@angular/core").InputSignal<string>;
  readonly slides: import("@angular/core").InputSignal<number | undefined>;
  readonly useKeyboard: import("@angular/core").InputSignal<boolean>;
  readonly useMouseWheel: import("@angular/core").InputSignal<boolean>;
  readonly orientation: import("@angular/core").InputSignal<Orientation>;
  readonly animationStart: import("@angular/core").OutputEmitterRef<number>;
  readonly change: import("@angular/core").OutputEmitterRef<number>;
  readonly currentIndex: import("@angular/core").WritableSignal<number>;
  readonly slidesList: import("@angular/core").Signal<readonly MatCarouselSlideComponent[]>;
  readonly visibleSlides: import("@angular/core").Signal<readonly MatCarouselSlideComponent[]>;
  readonly carouselContainerRef: import("@angular/core").Signal<ElementRef<HTMLDivElement>>;
  readonly carouselListRef: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly translation: import("@angular/core").WritableSignal<string>;
  private listKeyManager;
  private timer$;
  private readonly timerStop$;
  private animationPending;
  private animationTimeout;
  private pressed;
  private dragging;
  private dragStartX;
  private dragStartY;
  private readonly dragThreshold;
  private readonly renderer;
  private readonly platformId;
  private readonly destroyRef;
  private readonly injector;
  get currentSlide(): MatCarouselSlideComponent | null;
  constructor();
  ngAfterContentInit(): void;
  next(): void;
  previous(): void;
  slideTo(index: number): void;
  onKeyUp(event: KeyboardEvent): void;
  onMouseEnter(): void;
  onMouseLeave(): void;
  onMouseWheel(event: Event): void;
  onResize(): void;
  onTransitionEnd(event: TransitionEvent): void;
  onDragStart(event: PointerEvent): void;
  onDrag(event: PointerEvent, slideElem: HTMLElement): void;
  onDragEnd(event: PointerEvent, slideElem: HTMLElement): void;
  private isOutOfBounds;
  private isVisible;
  private getOffset;
  private getTranslation;
  private getWidth;
  private goto;
  private playAnimation;
  private scheduleAnimationEnd;
  private finishAnimation;
  private getTransitionDuration;
  private clearAnimationTimeout;
  private resetTimer;
  private startTimer;
  private stopTimer;
  static ɵfac: i0.ɵɵFactoryDeclaration<MatCarouselComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MatCarouselComponent, "mat-carousel", never, {
    "timings": {
      "alias": "timings";
      "required": false;
      "isSignal": true;
    };
    "svgIconOverrides": {
      "alias": "svgIconOverrides";
      "required": false;
      "isSignal": true;
    };
    "autoplay": {
      "alias": "autoplay";
      "required": false;
      "isSignal": true;
    };
    "interval": {
      "alias": "interval";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "hideArrows": {
      "alias": "hideArrows";
      "required": false;
      "isSignal": true;
    };
    "hideIndicators": {
      "alias": "hideIndicators";
      "required": false;
      "isSignal": true;
    };
    "pauseOnHover": {
      "alias": "pauseOnHover";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "maxWidth": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "maintainAspectRatio": {
      "alias": "maintainAspectRatio";
      "required": false;
      "isSignal": true;
    };
    "proportion": {
      "alias": "proportion";
      "required": false;
      "isSignal": true;
    };
    "slideHeight": {
      "alias": "slideHeight";
      "required": false;
      "isSignal": true;
    };
    "slides": {
      "alias": "slides";
      "required": false;
      "isSignal": true;
    };
    "useKeyboard": {
      "alias": "useKeyboard";
      "required": false;
      "isSignal": true;
    };
    "useMouseWheel": {
      "alias": "useMouseWheel";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "animationStart": "animationStart";
    "change": "change";
  }, ["slidesList"], never, true, never>;
}